﻿(function () {
    'use strict';

    angular.module('emixApp',
        ['ngRoute',
        'ngCookies',
        'ngAnimate',
        'emixApp.controllers',
        'emixApp.directives',
        'emixApp.services'
        ])
        .config(['$routeProvider', function ($routeProvider) {

            $routeProvider
                .when('/', {
                    controller: 'lobyMobiles',
                    templateUrl: 'ngApp/pages/devices/index.html'
                })
                .when('/device/:id', {
                    controller: 'device',
                    templateUrl: 'ngApp/pages/deviceDescription/index.html'
                })
                
                .otherwise({
                    redirectTo: '/'
                });

        }]);

    angular.module('emixApp.services', []);
    angular.module('emixApp.controllers', []);
    angular.module('emixApp.directives', []);
}());