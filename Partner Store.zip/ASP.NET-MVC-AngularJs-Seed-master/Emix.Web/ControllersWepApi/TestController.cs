﻿using Emix.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Emix.Web.ControllersWepApi
{
    public class TestController : ApiController
    {
        private static TableData tableData;
        private static Random randomGenerator;

        public static List<Mobile> Mobiles{ get; set; }

        static TestController()
        {
            int mobilesLength = 2;
            Mobiles = new List<Mobile>();
            var colors = getColors();
            var pics = getPictures();
            var pics2 = getPictures2();

            for (int i = 1; i < mobilesLength; i++)
               {
                var mobile = new Mobile(i,  "android", "samsung",  " galaxy", "nice phone", i * 2300, colors, pics);
                var mobile1 = new Mobile(i+1, "iphone", "apple",  " iphone 7", "best phone", i * 5000, colors, pics2);
                Mobiles.Add(mobile);
                Mobiles.Add(mobile1);
            }

        }

        private static List<string> getPictures()
        {
            var pics = new List<string>();
            pics.Add("\\img\\android.png");
      
            return pics;
        }
        private static List<string> getPictures2()
        {
            var pics = new List<string>();

            pics.Add("\\img\\iphone.png");
            return pics;
        }

        private static List<string> getColors()
        {
            var colors = new List<string>();
            colors.Add("#fff000");
            colors.Add("Blue");
            colors.Add("Red");
            return colors;
        }

        private decimal getRandom()
        {
            double val = randomGenerator.NextDouble();
            return (decimal)val * 1000;
        }

        public TestController() { }

        [HttpGet]
        public object getMobileDevice(int id)
        {
            var retVal = new Mobile();
            foreach (var mobile in Mobiles)
            {
                if(mobile.ID == id)
                {
                    retVal = mobile;
                    break;
                }
            }
            return Json(retVal);
        }

        [HttpGet]
        public object getMobiles()
        {
            return Json(Mobiles);
        }
    }

    public class TableData
    {
        public TableData()
        {
            this.Columns = new List<string>();
            this.Rows = new List<string>();
            this.Data = new List<List<decimal>>();
        }

        public List<string> Columns { get; set; }

        public List<string> Rows { get; set; }

        //list of rows
        public List<List<decimal>> Data { get; set; }
    }
 }
