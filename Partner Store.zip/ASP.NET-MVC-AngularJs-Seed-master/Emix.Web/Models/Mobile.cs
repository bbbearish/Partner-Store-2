﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Emix.Web.Models
{
    public class Mobile
    {
        public int ID { get; set; }
        public string Type { get; set; }
        public string Company { get; set; }
        public string Name { get; set; }
        public string Desc { get; set; }
        public double Price { get; set; }
        public List<string> Colors  { get; set; }
        public List<string> Pics { get; set; }

        public Mobile(int id, string type, string company, string name, string desc, double price, List<string> colors, List<string> pics)
        {
            this.ID = id;
            this.Type = type;
            this.Company = company;
            this.Name = name;
            this.Desc = desc;
            this.Price = price;
            this.Colors = colors;
            this.Pics = pics;
        }

        public Mobile()
        {
        }
    }
}